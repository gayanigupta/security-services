package com.user.security.poc.exception;

import lombok.Data;

import java.io.InputStream;
import java.text.MessageFormat;
import java.util.MissingResourceException;
import java.util.PropertyResourceBundle;
import java.util.ResourceBundle;

@Data
public class SecurityServiceException extends RuntimeException {

    private static final String MESSAGES_FILE = "errors.properties";
    private static final ResourceBundle BUNDLE = loadResources();

    private static final String MESSAGE_KEY_PREFIX = "error.";
    private static final String DETAILED_MESSAGE_KEY_SUFFIX = ".details";

    private final SecurityServiceErrorCode code;
    private final int httpStatus;
    private final String[] messageParameters;
    private final String[] detailMessageParameters;

    public SecurityServiceErrorCode getCode() {
        return code;
    }

    public int getHttpStatus() {
        return httpStatus;
    }

    public String[] getMessageParameters() {
        return messageParameters;
    }

    public String[] getDetailMessageParameters() {
        return detailMessageParameters;
    }

    public SecurityServiceException(SecurityServiceErrorCode code, int httpStatus, Throwable th) {
        this(code, httpStatus, null, null, th);
    }

    public SecurityServiceException(SecurityServiceErrorCode code, int httpStatus, String[] messageParameters,
            String[] detailMessageParameters) {
        this(code, httpStatus, messageParameters, detailMessageParameters, null);
    }

    public SecurityServiceException(SecurityServiceErrorCode code, int httpStatus, String[] messageParameters,
            String[] detailMessageParameters, Throwable cause) {
        super(cause);
        this.code = code;
        this.httpStatus = httpStatus;
        this.messageParameters = messageParameters;
        this.detailMessageParameters = detailMessageParameters;
    }

    private static String getResource(String key) {
        if (BUNDLE == null) {
            return key;
        }
        try {
            return BUNDLE.getString(key);
        } catch (MissingResourceException ex) {
            ex.printStackTrace();
        }
        return key;
    }

    public String getDetailMessage() {
        StringBuilder keyBuilder = new StringBuilder(MESSAGE_KEY_PREFIX).append(code.code())
                .append(DETAILED_MESSAGE_KEY_SUFFIX);
        String detailedMessageKey = keyBuilder.toString();
        String detailedMessagePattern = getResource(detailedMessageKey);

        return formatString(detailedMessagePattern, detailMessageParameters);
    }

    private static String formatString(String pattern, String[] args) {
        if (args == null || args.length == 0) {
            return pattern;
        }
        return MessageFormat.format(pattern, args);
    }

    private static final ResourceBundle loadResources() {
        try (InputStream is = SecurityServiceException.class.getClassLoader()
                .getResourceAsStream(MESSAGES_FILE)) {
            return new PropertyResourceBundle(is);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

}
