package com.user.security.poc.dto;

public enum UserRole {
    ROLE_ADMIN, ROLE_CREATE, ROLE_DELETE, ROLE_UPDATE, ROLE_READ
}
