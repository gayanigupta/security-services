package com.user.secirity;

import com.user.security.poc.service.user.UserService;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

@SpringBootTest
@RunWith(SpringRunner.class)
@ComponentScan({"com.user"})
public class UserServiceTest {

    @Autowired
    private UserService userService;

    @Test
    public void testUser() {
        System.out.println(userService);
    }
}
